using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Column : MonoBehaviour
{
    public int col;
    public Vector3 spawnLocation;
    public Vector3 targetlocation;
}
